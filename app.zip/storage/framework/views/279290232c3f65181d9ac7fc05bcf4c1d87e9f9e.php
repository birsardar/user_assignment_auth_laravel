<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Internship Task</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">


    <style>
        .center-content {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        body {
            font-family: 'Nunito', sans-serif;
        }
    </style>
</head>


<body class="antialiased">
    <div class="center-content bg-gray-100">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
            <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/home')); ?>"
                        class="  btn btn-primary text-sm text-gray-700 dark:text-gray-500 underline">Home</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>"
                        class="  btn btn-primary text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>

                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>"
                            class=" btn btn-primary ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>

            <div class="mt-8 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
                <!-- ... (other content) ... -->
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\xamlaravel\htdocs\user-auth-project\resources\views/welcome.blade.php ENDPATH**/ ?>